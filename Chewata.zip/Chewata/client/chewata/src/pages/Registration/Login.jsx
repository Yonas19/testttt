import React from 'react'

function Login() {
  return (
    <div>
      <div>
          <div className="form">
              <h2>Login</h2>
              <label htmlFor="">Username</label> <br />
              <input type="text" /> <br />
              <label htmlFor="">Email</label> <br />
              <input type="email" /> <br />
              <label htmlFor="">Password</label> <br />
        <input type="password" /> <br />
        <button type='submit'>Login</button>
    </div>
    </div>
    </div>
  )
}

export default Login
