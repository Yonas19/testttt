const mongoose = require("mongoose");
mongoose
  .connect("mongodb+srv://chewata:chewata123@chewata.6qakg.mongodb.net/", {
    userNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("connected"))
  .catch((err) => console.log(err));
const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    password : String,
})

const User = mongoose.model('User',userSchema)