import React from "react";
import Signup from "./pages/Registration/signup";
import Login from "./pages/Registration/Login";

function App() {
  return (
    <div>
      <Signup />
        
    </div>
  );
}

export default App;
